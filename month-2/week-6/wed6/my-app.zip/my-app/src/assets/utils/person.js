const personFactory = (age, color, name) => {
    return { age: age, name: name, color: color };
};

export default personFactory;
